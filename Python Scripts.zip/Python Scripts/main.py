# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 19:00:23 2019

@author: CEC
"""

#import module
#
#print('Hola, hiii quiero ser un modulo')

from module import sum1, prod1

zeroes=[0 for i in range(5)]
ones=[1 for i in range(5)]
print(sum1(zeroes))
print(prod1(ones))